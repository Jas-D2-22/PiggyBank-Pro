package com.example.mymoneyapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PinScreen(
    viewModel: MoneyViewModel,
    onPinVerified: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var showForgotPin by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GreenDark),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(text = "🐷", fontSize = 56.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "My Money App",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.7f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Enter your PIN",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(4) { index ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (index < enteredPin.length) Color.White
                                else Color.White.copy(alpha = 0.3f)
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    fontSize = 13.sp,
                    color = Color(0xFFFF8A80),
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            PinKeypad(
                onKeyPressed = { key ->
                    if (key == "⌫") {
                        if (enteredPin.isNotEmpty()) {
                            enteredPin = enteredPin.dropLast(1)
                            errorMessage = ""
                        }
                    } else if (enteredPin.length < 4) {
                        enteredPin += key
                        errorMessage = ""
                        if (enteredPin.length == 4) {
                            if (enteredPin == viewModel.userPin.value) {
                                onPinVerified()
                            } else {
                                errorMessage = "❌ Incorrect PIN. Try again."
                                enteredPin = ""
                            }
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Forgot PIN? Reset",
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.clickable { showForgotPin = true }
            )
        }
    }

    if (showForgotPin) {
        var answerInput by remember { mutableStateOf("") }
        var showNewPin by remember { mutableStateOf(false) }
        var newPin by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf("") }
        val randomQuestion = remember { viewModel.getRandomSecurityQuestion() }
        val questionIndex = randomQuestion.first
        val questionText = randomQuestion.second

        AlertDialog(
            onDismissRequest = { showForgotPin = false },
            title = {
                Text(
                    text = "🔐 Reset PIN",
                    fontWeight = FontWeight.Bold,
                    color = GreenDark
                )
            },
            text = {
                Column {
                    if (!showNewPin) {
                        Text(
                            text = questionText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TextField(
                            value = answerInput,
                            onValueChange = { answerInput = it },
                            label = { Text("Your answer") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (errorMsg.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = errorMsg,
                                fontSize = 12.sp,
                                color = Color.Red
                            )
                        }
                    } else {
                        Text(
                            text = "Enter your new 4 digit PIN:",
                            fontSize = 14.sp,
                            color = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TextField(
                            value = newPin,
                            onValueChange = { if (it.length <= 4) newPin = it },
                            label = { Text("New PIN") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!showNewPin) {
                            if (viewModel.verifySecurityAnswer(questionIndex, answerInput)) {
                                showNewPin = true
                                errorMsg = ""
                            } else {
                                errorMsg = "❌ Incorrect answer. Try again."
                            }
                        } else {
                            if (newPin.length == 4) {
                                viewModel.savePin(newPin)
                                showForgotPin = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (!showNewPin) "Verify" else "Save PIN",
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPin = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun PinSetupScreen(
    viewModel: MoneyViewModel,
    onSetupComplete: () -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var firstPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val questions = listOf(
        "What was your first pet's name?",
        "What city were you born in?",
        "What was the name of your first school?",
        "What was your childhood nickname?",
        "What is your mother's maiden name?",
        "What is your oldest sibling's name?",
        "What is your grandmother's first name?",
        "What is your favorite movie?",
        "What is your favorite sports team?",
        "What was your first car?",
        "What street did you grow up on?",
        "What was the name of your first best friend?",
        "What was the make of your first car?"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GreenDark),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(text = "🔐", fontSize = 48.sp)
            Spacer(modifier = Modifier.height(8.dp))

            when (step) {
                1 -> {
                    Text(
                        text = "Create Your PIN",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Enter a 4 digit PIN to secure your app",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        repeat(4) { index ->
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (index < firstPin.length) Color.White
                                        else Color.White.copy(alpha = 0.3f)
                                    )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    PinKeypad(
                        onKeyPressed = { key ->
                            if (key == "⌫") {
                                if (firstPin.isNotEmpty()) firstPin = firstPin.dropLast(1)
                            } else if (firstPin.length < 4) {
                                firstPin += key
                                if (firstPin.length == 4) step = 2
                            }
                        }
                    )
                }

                2 -> {
                    Text(
                        text = "Confirm Your PIN",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Enter your PIN again to confirm",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        repeat(4) { index ->
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (index < confirmPin.length) Color.White
                                        else Color.White.copy(alpha = 0.3f)
                                    )
                            )
                        }
                    }

                    if (errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage,
                            fontSize = 13.sp,
                            color = Color(0xFFFF8A80)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    PinKeypad(
                        onKeyPressed = { key ->
                            if (key == "⌫") {
                                if (confirmPin.isNotEmpty()) confirmPin = confirmPin.dropLast(1)
                                errorMessage = ""
                            } else if (confirmPin.length < 4) {
                                confirmPin += key
                                if (confirmPin.length == 4) {
                                    if (confirmPin == firstPin) {
                                        step = 3
                                        errorMessage = ""
                                    } else {
                                        errorMessage = "❌ PINs don't match. Try again."
                                        confirmPin = ""
                                    }
                                }
                            }
                        }
                    )
                }

                3 -> {
                    Text(
                        text = "Security Questions",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Pick 4 questions and answer them",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val selectedQuestions = remember { mutableStateListOf("", "", "", "") }
                    val answers = remember { mutableStateListOf("", "", "", "") }
                    val expandedIndex = remember { mutableStateOf(-1) }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        repeat(4) { i ->
                            Column {
                                Text(
                                    text = "Question ${i + 1} of 4",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box {
                                    OutlinedButton(
                                        onClick = { expandedIndex.value = i },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Text(
                                            text = if (selectedQuestions[i].isEmpty())
                                                "Choose a question..."
                                            else selectedQuestions[i],
                                            fontSize = 11.sp,
                                            color = Color.White,
                                            textAlign = TextAlign.Start,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = expandedIndex.value == i,
                                        onDismissRequest = { expandedIndex.value = -1 }
                                    ) {
                                        questions.forEach { question ->
                                            if (!selectedQuestions.contains(question) ||
                                                selectedQuestions[i] == question) {
                                                DropdownMenuItem(
                                                    text = { Text(question, fontSize = 12.sp) },
                                                    onClick = {
                                                        selectedQuestions[i] = question
                                                        expandedIndex.value = -1
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                TextField(
                                    value = answers[i],
                                    onValueChange = { answers[i] = it },
                                    label = {
                                        Text(
                                            "Your answer",
                                            color = Color.White.copy(alpha = 0.7f)
                                        )
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = TextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedContainerColor = Color.White.copy(alpha = 0.15f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.1f)
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val allFilled = selectedQuestions.all { it.isNotEmpty() } &&
                                    answers.all { it.isNotBlank() }
                            if (allFilled) {
                                viewModel.savePin(firstPin)
                                viewModel.saveSecurityQuestions(
                                    selectedQuestions.toList(),
                                    answers.toList()
                                )
                                onSetupComplete()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Save & Continue 🚀",
                            color = GreenDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PinKeypad(onKeyPressed: (String) -> Unit) {
    val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("", "0", "⌫")
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        keys.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                row.forEach { key ->
                    if (key.isEmpty()) {
                        Box(modifier = Modifier.size(72.dp))
                    } else {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                                .clickable { onKeyPressed(key) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = key,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}