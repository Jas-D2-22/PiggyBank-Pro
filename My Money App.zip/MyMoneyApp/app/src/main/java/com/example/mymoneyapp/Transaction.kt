package com.example.mymoneyapp

data class Transaction(
    val icon: String,
    val label: String,
    val amount: Double,
    val isIncome: Boolean,
    val category: String,
    val date: Long = System.currentTimeMillis()  // ← NEW
)