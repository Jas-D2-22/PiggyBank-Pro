package com.example.mymoneyapp  // ← change to match your package name

import android.os.Bundle
import androidx.compose.runtime.LaunchedEffect
import java.util.Calendar
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.mymoneyapp.MoneyViewModel
import com.example.mymoneyapp.Transaction

// --- Color constants ---
val GreenDark = Color(0xFF1B5E20)
val GreenMid = Color(0xFF4CAF50)
val GreenLight = Color(0xFF69F0AE)
val RedDark = Color(0xFFC62828)
val GoldDark = Color(0xFFF9A825)
val BlueDark = Color(0xFF1565C0)
val OrangeDeep = Color(0xFFBF360C)   // ← Deep Orange for Food
val SurfaceGray = Color(0xFFF5F5F5)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val SteelBlue = Color(0xFF1976D2)
val BrownDark = Color(0xFF5D4037)
val PinkRed = Color(0xFFAD1457)
val PurpleDark = Color(0xFF6A1B9A)
val TealDark = Color(0xFF00695C)
val GrayDark = Color(0xFF424242)
val YellowDark = Color(0xFFF57F17)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: MoneyViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            MaterialTheme(
                colorScheme = if (viewModel.isDarkMode.value) {
                    darkColorScheme()
                } else {
                    lightColorScheme()
                }
            ) {
                var isAuthenticated by remember { mutableStateOf(false) }
                var isPinSetup by remember { mutableStateOf(viewModel.userPin.value.isNotEmpty()) }

                when {
                    !isPinSetup -> {
                        PinSetupScreen(
                            viewModel = viewModel,
                            onSetupComplete = {
                                isPinSetup = true
                                isAuthenticated = true
                            }
                        )
                    }
                    !isAuthenticated -> {
                        PinScreen(
                            viewModel = viewModel,
                            onPinVerified = { isAuthenticated = true }
                        )
                    }
                    else -> {
                        MoneyApp()
                    }
                }
            }
        }
    }
}


// --- Category History Dialog ---
@Composable
fun CategoryHistoryDialog(
    category: String,
    icon: String,
    viewModel: MoneyViewModel,
    onDismiss: () -> Unit
) {
    var selectedMonths by remember { mutableStateOf(3) }

    val calendar = Calendar.getInstance()
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    calendar.add(Calendar.MONTH, -(selectedMonths - 1))
    val startTime = calendar.timeInMillis

    val filteredTransactions = viewModel.transactions
        .filter { !it.isIncome && it.category == category && it.date >= startTime }
        .sortedByDescending { it.date }

    val total = filteredTransactions.sumOf { it.amount }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "$icon $category History",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = GreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // --- Time Period Selector ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 3, 6).forEach { months ->
                        Button(
                            onClick = { selectedMonths = months },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMonths == months) GreenDark else Color.LightGray
                            ),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "$months Mo",
                                fontSize = 11.sp,
                                color = if (selectedMonths == months) Color.White else Color.DarkGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // --- Transaction List Header ---
                Text(
                    text = "Spending History",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(8.dp))

                HorizontalDivider(color = Color.LightGray)

                Spacer(modifier = Modifier.height(8.dp))

                if (filteredTransactions.isEmpty()) {
                    Text(
                        text = "No transactions in this period.",
                        fontSize = 12.sp,
                        fontStyle = FontStyle.Italic,
                        color = Color.Gray
                    )
                } else {
                    // --- Transaction Rows ---
                    filteredTransactions.forEach { tx ->
                        val dateFormat = java.text.SimpleDateFormat(
                            "MMM dd",
                            java.util.Locale.getDefault()
                        )
                        val dateStr = dateFormat.format(java.util.Date(tx.date))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = dateStr,
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.width(48.dp)
                            )
                            Text(
                                text = tx.label,
                                fontSize = 12.sp,
                                color = Color.DarkGray,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "-$${"%.2f".format(tx.amount)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = RedDark
                            )
                        }

                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // --- Total Row ---
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Total",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.DarkGray
                        )
                        Text(
                            text = "-$${"%.2f".format(total)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = RedDark
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = GreenDark)
            }
        }
    )
}

// --- Spending Chart Dialog ---
@Composable
fun SpendingChartDialog(
    viewModel: MoneyViewModel,
    isIncome: Boolean,
    onDismiss: () -> Unit
) {
    var selectedMonths by remember { mutableStateOf(3) }

    val categoryColors = mapOf(
        "Food" to OrangeDeep,
        "Fun" to BlueDark,
        "Save" to GoldDark,
        "Gas" to GrayDark,
        "Utilities" to YellowDark,
        "Car Ins" to SteelBlue,
        "Rent" to BrownDark,
        "Health" to PinkRed,
        "Clothing" to PurpleDark,
        "Phone" to TealDark
    )

    val categoryTotals = if (isIncome) {
        viewModel.transactions
            .filter { it.isIncome }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    } else {
        viewModel.getCategoryTotals(selectedMonths)
    }
    val monthlyTotals = if (isIncome) {
        viewModel.getMonthlyTotals(selectedMonths).map { (month, _) ->
            val total = viewModel.transactions
                .filter { it.isIncome }
                .sumOf { it.amount }
            Pair(month, total)
        }
    } else {
        viewModel.getMonthlyTotals(selectedMonths)
    }
    val maxCategoryValue = categoryTotals.values.maxOrNull() ?: 1.0
    val maxMonthlyValue = monthlyTotals.maxOfOrNull { it.second } ?: 1.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isIncome) "Income Overview" else "Expense Overview",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = GreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // --- Time Period Selector ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 3, 6).forEach { months ->
                        Button(
                            onClick = { selectedMonths = months },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMonths == months) GreenDark else Color.LightGray
                            ),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "$months Mo",
                                fontSize = 11.sp,
                                color = if (selectedMonths == months) Color.White else Color.DarkGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // --- Bar Chart ---
                Text(
                    text = "Spending by Category",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (categoryTotals.isEmpty()) {
                    Text(
                        text = "No expenses in this period.",
                        fontSize = 12.sp,
                        fontStyle = FontStyle.Italic,
                        color = Color.Gray
                    )
                } else {
                    categoryTotals.entries.sortedByDescending { it.value }.forEach { (category, amount) ->
                        val color = categoryColors[category] ?: GreenMid
                        val barPercent = (amount / maxCategoryValue).toFloat()
                        val icon = when (category) {
                            "Food" -> "🍔"
                            "Fun" -> "🎮"
                            "Save" -> "🏦"
                            "Gas" -> "⛽"
                            "Utilities" -> "💡"
                            "Car Ins" -> "🚗"
                            "Rent" -> "🏠"
                            "Health" -> "🏥"
                            "Clothing" -> "👕"
                            "Phone" -> "📱"
                            else -> "💰"
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "$icon $category",
                                fontSize = 11.sp,
                                modifier = Modifier.width(80.dp),
                                color = Color.DarkGray
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(20.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.LightGray.copy(alpha = 0.3f))
                            ) {
                                val animatedBar by animateFloatAsState(
                                    targetValue = barPercent,
                                    label = "bar $category"
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(animatedBar)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(color)
                                )
                            }
                            Text(
                                text = "$${"%.0f".format(amount)}",
                                fontSize = 11.sp,
                                modifier = Modifier.width(50.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End,
                                color = Color.DarkGray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // --- Line Graph ---
                Text(
                    text = "Monthly Spending Trend",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(8.dp))

                androidx.compose.foundation.Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    val padding = 20f
                    val graphWidth = width - padding * 2
                    val graphHeight = height - padding * 2

                    if (monthlyTotals.size > 1) {
                        val points = monthlyTotals.mapIndexed { index, (_, value) ->
                            val x = padding + (index.toFloat() / (monthlyTotals.size - 1)) * graphWidth
                            val y = padding + graphHeight - (value / maxMonthlyValue * graphHeight).toFloat()
                            androidx.compose.ui.geometry.Offset(x, y)
                        }

                        // Draw line
                        for (i in 0 until points.size - 1) {
                            drawLine(
                                color = GreenMid,
                                start = points[i],
                                end = points[i + 1],
                                strokeWidth = 3f,
                                cap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                        }

                        // Draw dots
                        points.forEach { point ->
                            drawCircle(
                                color = GreenDark,
                                radius = 6f,
                                center = point
                            )
                            drawCircle(
                                color = Color.White,
                                radius = 3f,
                                center = point
                            )
                        }
                    } else {
                        drawLine(
                            color = Color.LightGray,
                            start = androidx.compose.ui.geometry.Offset(padding, height / 2),
                            end = androidx.compose.ui.geometry.Offset(width - padding, height / 2),
                            strokeWidth = 2f
                        )
                    }
                }

                // Month labels
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    monthlyTotals.forEach { (month, _) ->
                        Text(
                            text = month,
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = GreenDark)
            }
        }
    )
}
// --- Smart Tip Card ---
@Composable
fun SmartTipCard(viewModel: MoneyViewModel, isDarkMode: Boolean) {
    val tip = viewModel.getSmartTip()

    if (viewModel.transactions.isEmpty()) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = "💡 Smart Tip",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isDarkMode) DarkSurface
                    else GoldDark.copy(alpha = 0.1f)
                )
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = tip,
                fontSize = 13.sp,
                color = if (isDarkMode) Color.White else Color.DarkGray,
                lineHeight = 20.sp
            )
        }
    }
}
// --- Monthly Summary Card ---
@Composable
fun MonthlySummaryCard(viewModel: MoneyViewModel, isDarkMode: Boolean) {
    val result = viewModel.getBestAndWorstMonths()
    val best = result.first
    val worst = result.second

    if (best == null && worst == null) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = "📊 Monthly Summary",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (isDarkMode) DarkSurface else SurfaceGray)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Best Month
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = "🏆 Best Month",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = best?.first ?: "--",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = GreenMid
                )
                Text(
                    text = "$${"%.2f".format(best?.second ?: 0.0)}",
                    fontSize = 13.sp,
                    color = GreenMid
                )
            }

            // Divider
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(60.dp)
                    .background(Color.LightGray.copy(alpha = 0.5f))
            )

            // Worst Month
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "📉 Worst Month",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = worst?.first ?: "--",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = RedDark
                )
                Text(
                    text = "$${"%.2f".format(worst?.second ?: 0.0)}",
                    fontSize = 13.sp,
                    color = RedDark
                )
            }
        }
    }
}
// --- Pie Chart Composable ---
@Composable
fun CategoryPieChart(transactions: List<Transaction>) {
    val expenseCategories = mapOf(
        "Food" to OrangeDeep,
        "Fun" to BlueDark,
        "Save" to GoldDark,
        "Gas" to GrayDark,
        "Utilities" to YellowDark,
        "Car Ins" to SteelBlue,
        "Rent" to BrownDark,
        "Health" to PinkRed,
        "Clothing" to PurpleDark,
        "Phone" to TealDark
    )

    // Total spent per category
    val totals = expenseCategories.keys.associateWith { category ->
        transactions
            .filter { !it.isIncome && it.category == category }
            .sumOf { it.amount }
    }

    val grandTotal = totals.values.sum()

    // Don't show chart if no expenses yet
    if (grandTotal == 0.0) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No expenses to display yet.",
                fontSize = 13.sp,
                fontStyle = FontStyle.Italic,
                color = Color.Gray
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // --- Canvas Pie Chart ---
        androidx.compose.foundation.Canvas(
            modifier = Modifier
                .size(200.dp)
                .semantics { contentDescription = "Pie chart showing spending by category" }
        ) {
            val diameter = size.minDimension
            val radius = diameter / 2f
            val topLeft = androidx.compose.ui.geometry.Offset(
                (size.width - diameter) / 2f,
                (size.height - diameter) / 2f
            )
            val rect = androidx.compose.ui.geometry.Size(diameter, diameter)

            var startAngle = -90f

            expenseCategories.forEach { (category, color) ->
                val amount = totals[category] ?: 0.0
                if (amount > 0.0) {
                    val sweep = ((amount / grandTotal) * 360f).toFloat()
                    drawArc(
                        color = color,
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = true,
                        topLeft = topLeft,
                        size = rect
                    )
                    startAngle += sweep
                }
            }

            // White circle in center for donut effect
            drawCircle(
                color = androidx.compose.ui.graphics.Color.White,
                radius = radius * 0.52f,
                center = center
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Legend ---
        expenseCategories.forEach { (category, color) ->
            val amount = totals[category] ?: 0.0
            if (amount > 0.0) {
                val percent = ((amount / grandTotal) * 100).toInt()
                val icon = when (category) {
                    "Food" -> "🍔"
                    "Fun" -> "🎮"
                    "Save" -> "🏦"
                    else -> "💰"
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 32.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(color)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$icon $category",
                            fontSize = 13.sp,
                            color = Color.DarkGray
                        )
                    }
                    Text(
                        text = "$percent%  (${"%.2f".format(amount)})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = color
                    )
                }
            }
        }
    }
}

// --- Confetti Animation ---
@Composable
fun ConfettiOverlay() {
    val particles = remember {
        List(80) {
            androidx.compose.animation.core.Animatable(0f)
        }
    }
    val colors = listOf(
        GreenLight, GoldDark, Color(0xFFFF8A80),
        Color(0xFF82B1FF), Color(0xFFEA80FC), Color.White
    )

    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        particles.forEach { particle ->
            scope.launch {
                particle.animateTo(
                    targetValue = 1f,
                    animationSpec = androidx.compose.animation.core.tween(
                        durationMillis = (1000..2000).random(),
                        delayMillis = (0..500).random()
                    )
                )
            }
        }
    }

    androidx.compose.foundation.Canvas(
        modifier = Modifier.fillMaxSize()
    ) {
        particles.forEachIndexed { index, particle ->
            val progress = particle.value
            val x = (index * 37f) % size.width
            val y = progress * size.height
            val color = colors[index % colors.size]
            val rotation = progress * 720f

            drawCircle(
                color = color.copy(alpha = (1f - progress).coerceIn(0f, 1f)),
                radius = (4f + (index % 4) * 2f),
                center = androidx.compose.ui.geometry.Offset(
                    x + kotlin.math.sin(rotation.toDouble()).toFloat() * 20f,
                    y
                )
            )
        }
    }
}

// --- Transaction Row composable ---
@Composable
fun TransactionRow(tx: Transaction, onDelete: () -> Unit) {  // ← CHANGED
    val amountColor = when {
        tx.isIncome && tx.category == "Savings" -> GoldDark
        tx.isIncome -> GreenMid
        else -> RedDark
    }
    val sign = if (tx.isIncome) "+" else "-"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(SurfaceGray)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .semantics {
                contentDescription = "${tx.label}, ${if (tx.isIncome) "income" else "expense"} of ${"%.2f".format(tx.amount)} dollars"
            },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon + Label
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "${tx.icon}  ${tx.label}",
                fontSize = 14.sp,
                color = Color.DarkGray
            )
            Text(
                text = java.text.SimpleDateFormat(
                    "MMM dd, yyyy",
                    java.util.Locale.getDefault()
                ).format(java.util.Date(tx.date)),
                fontSize = 11.sp,
                color = Color.Gray
            )
        }
        // Amount
        Text(
            text = "$sign$${"%.2f".format(tx.amount)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = amountColor
        )
        Spacer(modifier = Modifier.width(8.dp))  // ← NEW
        // Delete button
        IconButton(                               // ← NEW
            onClick = onDelete,
            modifier = Modifier
                .size(32.dp)
                .semantics { contentDescription = "Delete ${tx.label} transaction" }
        ) {
            Text(text = "🗑️", fontSize = 16.sp)
        }
    }
}

@Composable
fun MoneyApp() {


    val viewModel: MoneyViewModel = viewModel()
    var warningLimit by viewModel.warningLimit
    val warningLimitInput = remember { mutableStateOf("") }
    val showWarningSetup = remember { mutableStateOf(false) }
    val showThemePicker = remember { mutableStateOf(false) }
    var themeColorHex by viewModel.themeColorHex
    val themeColor = remember(themeColorHex) {
        Color(android.graphics.Color.parseColor(themeColorHex))
    }
    val showConfetti = remember { mutableStateOf(false) }
    val wasGoalReached = remember { mutableStateOf(false) }
    val isFlashing = remember { mutableStateOf(false) }
    var isDarkMode by viewModel.isDarkMode
    var balance by viewModel.balance
    var inputAmount by viewModel.inputAmount
    val isLowBalance = balance < warningLimit && warningLimit > 0.0
    var inputLabel by viewModel.inputLabel
    var selectedCategory by viewModel.selectedCategory
    var selectedIncomeIcon by viewModel.selectedIncomeIcon
    var goal by viewModel.goal
    var showGoalDialog by viewModel.showGoalDialog
    var goalInput by viewModel.goalInput
    var goalIcon by viewModel.goalIcon
    var goalName by viewModel.goalName
    var userName by viewModel.userName
    val showNameDialog = remember { mutableStateOf(userName.isEmpty()) }
    val showInsufficientFundsDialog = remember { mutableStateOf(false) }
    val pendingExpenseAmount = remember { mutableStateOf(0.0) }
    val transactions = viewModel.transactions
    val selectedChartCategory = remember { mutableStateOf("") }
    val showCategoryHistory = remember { mutableStateOf(false) }
    var showIncomeChart = remember { mutableStateOf(false) }
    var showExpenseChart = remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current  // ← NEW

    fun shareTransactions() {                                         // ← NEW
        val totalIncome = transactions.filter { it.isIncome }.sumOf { it.amount }
        val totalExpenses = transactions.filter { !it.isIncome }.sumOf { it.amount }

        val sb = StringBuilder()
        sb.appendLine("💰 My Money App Summary")
        sb.appendLine("========================")
        sb.appendLine("Balance:       $${"%.2f".format(balance)}")
        sb.appendLine("Total Income:  +$${"%.2f".format(totalIncome)}")
        sb.appendLine("Total Expenses: -$${"%.2f".format(totalExpenses)}")
        sb.appendLine("Savings Goal:  $${"%.2f".format(balance)}")
        sb.appendLine()
        sb.appendLine("--- Transactions ---")
        transactions.reversed().forEach { tx ->
            val sign = if (tx.isIncome) "+" else "-"
            sb.appendLine("${tx.icon} ${tx.label}  $sign$${"%.2f".format(tx.amount)}  [${tx.category}]")
        }

        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "My Money App Summary")
            putExtra(android.content.Intent.EXTRA_TEXT, sb.toString())
        }
        context.startActivity(
            android.content.Intent.createChooser(intent, "Share via")
        )
    }
    val categories = listOf(
        "Food", "Fun", "Save", "Gas", "Utilities",
        "Car Ins", "Rent", "Health", "Clothing", "Phone"
    )


    val amountSaved = transactions
        .filter { it.category == "Save" && !it.isIncome }
        .sumOf { it.amount }
    val amountLeft = (goal - amountSaved).coerceAtLeast(0.0)
    val progress = if (goal > 0.0) (amountSaved / goal).coerceIn(0.0, 1.0) else 0.0

    // Trigger confetti when goal is reached
    LaunchedEffect(progress) {
        if (progress >= 1.0 && goal > 0.0 && !wasGoalReached.value) {
            wasGoalReached.value = true
            showConfetti.value = true
            // ← removed the auto dismiss
        } else if (progress < 1.0) {
            wasGoalReached.value = false
        }
    }
    val animatedProgress by animateFloatAsState(
        targetValue = progress.toFloat(),
        label = "savings progress"
    )

    // Flash 3 times when balance goes low
    LaunchedEffect(isLowBalance) {
        if (isLowBalance) {
            repeat(3) {
                isFlashing.value = true
                kotlinx.coroutines.delay(300)
                isFlashing.value = false
                kotlinx.coroutines.delay(300)
            }
        }
    }

    val headerColor by animateColorAsState(
        targetValue = when {
            isFlashing.value -> RedDark
            isLowBalance -> RedDark
            else -> themeColor
        },
        animationSpec = tween(durationMillis = 300),
        label = "header flash",
        finishedListener = {
            if (isFlashing.value) {
                isFlashing.value = false
            }
        }
    )

    fun getCategoryIcon(category: String) = when (category) {
        "Food" -> "🍔"
        "Fun" -> "🎮"
        "Save" -> "🏦"
        "Gas" -> "⛽"
        "Utilities" -> "💡"
        "Car Ins" -> "🚗"
        "Rent" -> "🏠"
        "Health" -> "🏥"
        "Clothing" -> "👕"
        "Phone" -> "📱"
        else -> "💰"
    }

    fun getCategoryColor(category: String, isSelected: Boolean): Color {
        if (!isSelected) return Color.Transparent
        return when (category) {
            "Food" -> OrangeDeep
            "Fun" -> BlueDark
            "Save" -> GoldDark
            "Gas" -> GrayDark
            "Utilities" -> YellowDark
            "Car Ins" -> SteelBlue
            "Rent" -> BrownDark
            "Health" -> PinkRed
            "Clothing" -> PurpleDark
            "Phone" -> TealDark
            else -> Color.Transparent
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDarkMode) DarkBackground else SurfaceGray),
        contentAlignment = Alignment.TopCenter
    )
     {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {

            // --- Green Header Banner ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(headerColor)
                    .padding(horizontal = 20.dp, vertical = 24.dp)
                    .semantics { contentDescription = "Balance and savings goal section" }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (userName.isNotEmpty()) "👋 Welcome, $userName!" else "My Money App",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "⚠️",
                            fontSize = 20.sp,
                            modifier = Modifier.clickable { showWarningSetup.value = true }
                        )
                        Text(
                            text = "🎨",
                            fontSize = 20.sp,
                            modifier = Modifier.clickable { showThemePicker.value = true }
                        )
                        Text(
                            text = if (isDarkMode) "☀️" else "🌙",
                            fontSize = 20.sp,
                            modifier = Modifier.clickable { isDarkMode = !isDarkMode }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "$${"%.2f".format(balance)}",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White,
                    modifier = Modifier.semantics {
                        contentDescription = "Current balance is ${"%.2f".format(balance)} dollars"
                    }
                )
                if (isLowBalance) {
                    Text(
                        text = "⚠️ Low Balance Warning!",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier
                            .background(
                                RedDark.copy(alpha = 0.4f),
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))




                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.1f))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Total Income — tappable
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.clickable { showIncomeChart.value = true }
                    ) {
                        Text(
                            text = "📈 Income",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "+$${"%.2f".format(transactions.filter { it.isIncome }.sumOf { it.amount })}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = GreenLight
                        )
                        Text(
                            text = "tap for details",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }

                    // Divider line
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(40.dp)
                            .background(Color.White.copy(alpha = 0.2f))
                    )

                    // Total Expenses — tappable
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.clickable { showExpenseChart.value = true }
                    ) {
                        Text(
                            text = "📉 Expenses",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "-$${"%.2f".format(transactions.filter { !it.isIncome }.sumOf { it.amount })}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF8A80)
                        )
                        Text(
                            text = "tap for details",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }

// Show Income Chart Dialog
                if (showIncomeChart.value) {
                    SpendingChartDialog(
                        viewModel = viewModel,
                        isIncome = true,
                        onDismiss = { showIncomeChart.value = false }
                    )
                }

// Show Expense Chart Dialog
                if (showExpenseChart.value) {
                    SpendingChartDialog(
                        viewModel = viewModel,
                        isIncome = false,
                        onDismiss = { showExpenseChart.value = false }
                    )
                }

                // Show Category History Dialog
                if (showCategoryHistory.value) {
                    CategoryHistoryDialog(
                        category = selectedChartCategory.value,
                        icon = getCategoryIcon(selectedChartCategory.value),
                        viewModel = viewModel,
                        onDismiss = { showCategoryHistory.value = false }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$goalIcon $goalName",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {  // ← NEW
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${"%.0f".format(animatedProgress * 100)}% of $${"%.2f".format(goal)}",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "$${"%.2f".format(amountSaved)} saved",
                                fontSize = 11.sp,
                                color = GreenLight
                            )
                            Text(
                                text = "$${"%.2f".format(amountLeft)} left",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                goalInput = goal.toInt().toString()
                                showGoalDialog = true
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                        ) {
                            Text(
                                "✏️ Edit",
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))

                // Animated progress bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color.White.copy(alpha = 0.2f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProgress)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(999.dp))
                            .background(GreenLight)
                    )
                }
            }

            // Goal reached message and confetti
            if (showConfetti.value) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(GreenDark.copy(alpha = 0.95f))
                        .clickable { showConfetti.value = false },
                    contentAlignment = Alignment.Center
                ) {
                    ConfettiOverlay()
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "🎉",
                            fontSize = 80.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Goal Reached!",
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Congratulations!",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Medium,
                            color = GreenLight
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "$goalIcon $goalName",
                            fontSize = 20.sp,
                            color = GoldDark,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$${"%.2f".format(amountSaved)} saved!",
                            fontSize = 18.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(32.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            // Start New Goal button
                            Button(
                                onClick = {
                                    // Reset goal tracking only — don't touch balance or transactions
                                    goal = 0.0
                                    goalInput = ""
                                    showConfetti.value = false
                                    wasGoalReached.value = false
                                    showGoalDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GoldDark
                                ),
                                shape = RoundedCornerShape(999.dp)
                            ) {
                                Text(
                                    text = "🔄 New Goal",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Keep and Continue button
                            Button(
                                onClick = {
                                    showConfetti.value = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GreenMid
                                ),
                                shape = RoundedCornerShape(999.dp)
                            ) {
                                Text(
                                    text = "✅ Keep Going",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Tap anywhere to continue",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.5f),
                            fontStyle = FontStyle.Italic
                        )
                    }
                }
            }

            // --- Icon + Category Pills Row (Scrollable) ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDarkMode) DarkSurface else Color.White)
                    .padding(vertical = 12.dp)
            ) {
                // Top row: 💵 Cash pill (income)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.Start
                ) {
                    val incomeSelected = selectedIncomeIcon == "💵"
                    OutlinedButton(
                        onClick = { selectedIncomeIcon = "💵" },
                        shape = RoundedCornerShape(999.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (incomeSelected) GreenDark else Color.Transparent,
                            contentColor = if (incomeSelected) Color.White else Color.Gray
                        ),
                        border = BorderStroke(
                            width = if (incomeSelected) 0.dp else 1.dp,
                            color = if (incomeSelected) Color.Transparent else Color.LightGray
                        ),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .semantics {
                                contentDescription = "Cash income icon, ${if (incomeSelected) "selected" else "not selected"}"
                            }
                    ) {
                        Text(text = "💵 Cash", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable category pills row
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { category ->
                        val isSelected = category == selectedCategory
                        val bgColor = getCategoryColor(category, isSelected)
                        val textColor = if (isSelected) Color.White else Color.Gray
                        val borderColor = if (isSelected) Color.Transparent else Color.LightGray

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { selectedCategory = category },
                                shape = RoundedCornerShape(999.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = bgColor,
                                    contentColor = textColor
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 0.dp else 1.dp,
                                    color = borderColor
                                ),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .semantics {
                                        contentDescription = "$category category, ${if (isSelected) "selected" else "not selected"}"
                                    }
                            ) {
                                Text(
                                    text = "${getCategoryIcon(category)} $category",
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Clip
                                )
                            }
                            // 📊 Chart icon
                            Text(
                                text = "📊",
                                fontSize = 14.sp,
                                modifier = Modifier
                                    .padding(start = 2.dp)
                                    .clickable {
                                        selectedChartCategory.value = category
                                        showCategoryHistory.value = true
                                    }
                            )
                        }
                   }
}
            }

            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))

            // --- Input Fields and Buttons ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDarkMode) DarkSurface else Color.White)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextField(
                    value = inputAmount,
                    onValueChange = { inputAmount = it },
                    label = { Text("Enter Amount") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .semantics { contentDescription = "Amount input. Enter a dollar amount." },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal) // ← NEW
                )

                TextField(
                    value = inputLabel,
                    onValueChange = { inputLabel = it },
                    label = { Text("Label (Allowance, Snacks...)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .semantics {
                            contentDescription = "Label input. Describe this transaction."
                        },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Add Income button
                    Button(
                        onClick = {
                            val amount = inputAmount.toDoubleOrNull()
                            if (amount != null && amount > 0) {
                                viewModel.transactions.add(
                                    Transaction(
                                        icon = selectedIncomeIcon,
                                        label = inputLabel.ifBlank { "Income" },
                                        amount = amount,
                                        isIncome = true,
                                        category = selectedCategory
                                    )
                                )
                                viewModel.balance.value += amount
                                inputAmount = ""
                                inputLabel = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenMid),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .semantics {
                                contentDescription =
                                    "Add Income button. Adds entered amount to your balance."
                            }
                    ) {
                        Text("+ Add Income", color = Color.White, fontWeight = FontWeight.Medium)
                    }

                    // Add Expense button
                    Button(
                        onClick = {
                            val amount = inputAmount.toDoubleOrNull()
                            if (amount != null && amount > 0) {
                                if (amount > balance) {
                                    showInsufficientFundsDialog.value = true
                                    pendingExpenseAmount.value = amount
                                    isFlashing.value = true
                                } else {
                                    viewModel.transactions.add(
                                        Transaction(
                                            icon = getCategoryIcon(selectedCategory),
                                            label = inputLabel.ifBlank { selectedCategory },
                                            amount = amount,
                                            isIncome = false,
                                            category = selectedCategory
                                        )
                                    )
                                    viewModel.balance.value -= amount
                                    inputAmount = ""
                                    inputLabel = ""
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RedDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .semantics {
                                contentDescription =
                                    "Add Expense button. Subtracts entered amount from your balance."
                            }
                    ) {
                        Text("- Add Expense", color = Color.White, fontWeight = FontWeight.Medium)
                    }
                }
            }

            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))

            // --- Spending Chart ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDarkMode) DarkSurface else Color.White)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Spending Breakdown",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.Gray
                )
                SmartTipCard(viewModel = viewModel, isDarkMode = isDarkMode)
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))
                MonthlySummaryCard(viewModel = viewModel, isDarkMode = isDarkMode)
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))
                CategoryPieChart(transactions = transactions)
            }


            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))

            // --- Transaction List ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDarkMode) DarkSurface else Color.White)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Transactions",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.Gray
                    )
                    TextButton(
                        onClick = { shareTransactions() },
                        enabled = transactions.isNotEmpty()
                    ) {
                        Text(
                            text = "📤 Share",
                            fontSize = 12.sp,
                            color = if (transactions.isNotEmpty()) GreenDark else Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (transactions.isEmpty()) {
                    Text(
                        text = "No transactions yet.",
                        fontSize = 13.sp,
                        fontStyle = FontStyle.Italic,
                        color = Color.Gray
                    )
                } else {
                    transactions.reversed().forEach { tx ->
                        TransactionRow(
                            tx = tx,
                            onDelete = {
                                if (tx.isIncome) viewModel.balance.value -= tx.amount
                                else viewModel.balance.value += tx.amount
                                viewModel.transactions.remove(tx)
                            }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }
    }


    // Edit Goal Dialog
    if (showGoalDialog) {
        val savingsGoals = listOf(
            Pair("🏠", "House Fund"),
            Pair("🚗", "Car Fund"),
            Pair("🚲", "Bike Fund"),
            Pair("✈️", "Vacation Fund"),
            Pair("🎵", "Concert Fund"),
            Pair("🎓", "College Fund"),
            Pair("💍", "Wedding Fund"),
            Pair("📱", "Phone Fund"),
            Pair("💻", "Laptop Fund"),
            Pair("🏖️", "Beach Trip")
        )

        AlertDialog(
            onDismissRequest = { showGoalDialog = false },
            title = { Text("Set Savings Goal") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    TextField(
                        value = goalInput,
                        onValueChange = { goalInput = it },
                        label = { Text("Goal amount ($)") },
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "What are you saving for?",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Icon grid — 5 per row
                    savingsGoals.chunked(5).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { (icon, name) ->
                                val isSelected = goalIcon == icon
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSelected) GreenDark
                                            else Color.LightGray.copy(alpha = 0.3f)
                                        )
                                        .clickable {
                                            goalIcon = icon
                                            goalName = name
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = icon, fontSize = 22.sp)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Selected: $goalIcon $goalName",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = GreenDark
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val newGoal = goalInput.toDoubleOrNull()
                    if (newGoal != null && newGoal > 0) {
                        goal = newGoal
                    }
                    showGoalDialog = false
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGoalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
    // Insufficient Funds Dialog
    if (showInsufficientFundsDialog.value) {
        AlertDialog(
            onDismissRequest = { showInsufficientFundsDialog.value = false },
            title = {
                Text(
                    text = "⚠️ Insufficient Funds",
                    fontWeight = FontWeight.Bold,
                    color = RedDark
                )
            },
            text = {
                Column {
                    Text(
                        text = "You don't have enough money for this expense.",
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your balance: $${"%.2f".format(balance)}",
                        fontSize = 13.sp,
                        color = GreenMid,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Expense amount: $${"%.2f".format(pendingExpenseAmount.value)}",
                        fontSize = 13.sp,
                        color = RedDark,
                        fontWeight = FontWeight.Medium
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.transactions.add(
                        Transaction(
                            icon = getCategoryIcon(selectedCategory),
                            label = inputLabel.ifBlank { selectedCategory },
                            amount = pendingExpenseAmount.value,
                            isIncome = false,
                            category = selectedCategory
                        )
                    )
                    viewModel.balance.value -= pendingExpenseAmount.value
                    inputAmount = ""
                    inputLabel = ""
                    showInsufficientFundsDialog.value = false
                }) {
                    Text("Add Anyway", color = RedDark)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showInsufficientFundsDialog.value = false
                }) {
                    Text("Cancel", color = GreenDark)
                }
            }
        )
    }

    // Welcome Dialog
    if (showNameDialog.value) {
        var nameInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { },
            title = {
                Text(
                    text = "👋 Welcome!",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = GreenDark
                )
            },
            text = {
                Column {
                    Text(
                        text = "What's your name?",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Your name") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "We'll personalize your Money App experience!",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        fontStyle = FontStyle.Italic
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isNotBlank()) {
                            viewModel.saveUserName(nameInput.trim())
                            showNameDialog.value = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Let's Go! 🚀", color = Color.White)
                }
            }
        )
    }
    // Theme Picker Dialog
    if (showThemePicker.value) {
        val themes = listOf(
            Pair("#1B5E20", "🌿 Forest"),
            Pair("#0D47A1", "🌊 Ocean"),
            Pair("#BF360C", "🌅 Sunset"),
            Pair("#4A148C", "💜 Purple"),
            Pair("#004D40", "🌊 Teal"),
            Pair("#F57F17", "✨ Gold"),
            Pair("#880E4F", "🌹 Rose"),
            Pair("#37474F", "🪨 Slate")
        )

        AlertDialog(
            onDismissRequest = { showThemePicker.value = false },
            title = {
                Text(
                    text = "Choose Your Theme",
                    fontWeight = FontWeight.Bold,
                    color = themeColor
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Pick a color for your app header",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    themes.chunked(4).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { (hex, name) ->
                                val isSelected = themeColorHex == hex
                                val color = Color(android.graphics.Color.parseColor(hex))
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(52.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(color)
                                            .clickable { themeColorHex = hex }
                                            .then(
                                                if (isSelected) Modifier.padding(3.dp) else Modifier
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Text(text = "✓", fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = name,
                                        fontSize = 9.sp,
                                        color = Color.Gray,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemePicker.value = false }) {
                    Text("Done", color = themeColor)
                }
            }
        )
    }
    // Low Balance Warning Setup Dialog
    if (showWarningSetup.value) {
        AlertDialog(
            onDismissRequest = { showWarningSetup.value = false },
            title = {
                Text(
                    text = "⚠️ Low Balance Warning",
                    fontWeight = FontWeight.Bold,
                    color = RedDark
                )
            },
            text = {
                Column {
                    Text(
                        text = "Warn me when my balance drops below:",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = warningLimitInput.value,
                        onValueChange = { warningLimitInput.value = it },
                        label = { Text("Warning amount ($)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (warningLimit > 0.0) {
                        Text(
                            text = "Current limit: $${"%.2f".format(warningLimit)}",
                            fontSize = 12.sp,
                            color = GreenMid,
                            fontStyle = FontStyle.Italic
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val limit = warningLimitInput.value.toDoubleOrNull()
                        if (limit != null && limit > 0) {
                            warningLimit = limit
                        }
                        showWarningSetup.value = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Set Warning", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWarningSetup.value = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }
}