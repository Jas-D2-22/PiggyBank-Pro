package com.example.mymoneyapp

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import java.util.Calendar
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel

class MoneyViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("money_app_prefs", Context.MODE_PRIVATE)
    var userName = mutableStateOf(prefs.getString("user_name", "") ?: "")

    fun saveUserName(name: String) {
        userName.value = name
        prefs.edit().putString("user_name", name).apply()
    }
    var warningLimit = mutableStateOf(0.0)
    var showWarningSetup = mutableStateOf(false)
    var balance = mutableStateOf(0.0)
    var themeColorHex = mutableStateOf("#1B5E20")
    var isDarkMode = mutableStateOf(false)
    var inputAmount = mutableStateOf("")
    var inputLabel = mutableStateOf("")
    var selectedCategory = mutableStateOf("Food")
    var selectedIncomeIcon = mutableStateOf("Cash")
    var goal = mutableStateOf(0.0)
    var showGoalDialog = mutableStateOf(false)
    var goalInput = mutableStateOf("")

    var goalIcon = mutableStateOf("🏠")

    var goalName = mutableStateOf("House Fund")
    val transactions = mutableStateListOf<Transaction>()

    var userPin = mutableStateOf(prefs.getString("user_pin", "") ?: "")
    var securityQuestions = mutableStateOf(
        listOf(
            prefs.getString("security_question_1", "") ?: "",
            prefs.getString("security_question_2", "") ?: "",
            prefs.getString("security_question_3", "") ?: "",
            prefs.getString("security_question_4", "") ?: ""
        )
    )
    var securityAnswers = mutableStateOf(
        listOf(
            prefs.getString("security_answer_1", "") ?: "",
            prefs.getString("security_answer_2", "") ?: "",
            prefs.getString("security_answer_3", "") ?: "",
            prefs.getString("security_answer_4", "") ?: ""
        )
    )
    fun savePin(pin: String) {
        userPin.value = pin
        prefs.edit().putString("user_pin", pin).apply()
    }

    fun saveSecurityQuestions(
        questions: List<String>,
        answers: List<String>
    ) {
        securityQuestions.value = questions
        securityAnswers.value = answers.map { it.lowercase().trim() }
        prefs.edit().apply {
            questions.forEachIndexed { index, q ->
                putString("security_question_${index + 1}", q)
            }
            answers.forEachIndexed { index, a ->
                putString("security_answer_${index + 1}", a.lowercase().trim())
            }
            apply()
        }
    }

    fun getRandomSecurityQuestion(): Pair<Int, String> {
        val nonEmpty = securityQuestions.value
            .mapIndexed { index, q -> Pair(index, q) }
            .filter { it.second.isNotEmpty() }
        return if (nonEmpty.isEmpty()) Pair(0, "")
        else nonEmpty.random()
    }

    fun verifySecurityAnswer(questionIndex: Int, answer: String): Boolean {
        return answer.lowercase().trim() == securityAnswers.value[questionIndex]
    }

    // ← NEW: Get transactions for a specific month
    fun getTransactionsForMonth(monthsBack: Int): List<Transaction> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        calendar.add(Calendar.MONTH, -monthsBack)
        val startTime = calendar.timeInMillis
        calendar.add(Calendar.MONTH, 1)
        val endTime = calendar.timeInMillis
        return transactions.filter { it.date >= startTime && it.date < endTime }
    }

    //  Get monthly totals for line graph
    fun getMonthlyTotals(months: Int): List<Pair<String, Double>> {
        val calendar = Calendar.getInstance()
        val monthNames = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        val result = mutableListOf<Pair<String, Double>>()
        for (i in months - 1 downTo 0) {
            val monthTransactions = getTransactionsForMonth(i)
            val total = monthTransactions
                .filter { !it.isIncome }
                .sumOf { it.amount }
            val cal = Calendar.getInstance()
            cal.add(Calendar.MONTH, -i)
            val monthName = monthNames[cal.get(Calendar.MONTH)]
            result.add(Pair(monthName, total))
        }
        return result
    }

    // Get category totals for bar chart
    fun getCategoryTotals(months: Int): Map<String, Double> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        calendar.add(Calendar.MONTH, -(months - 1))
        val startTime = calendar.timeInMillis
        return transactions
            .filter { !it.isIncome && it.date >= startTime }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }

    fun getBestAndWorstMonths(): Pair<Pair<String, Double>?, Pair<String, Double>?> {
        val monthlyTotals = getMonthlyTotals(6)
        val nonZero = monthlyTotals.filter { it.second > 0.0 }
        if (nonZero.isEmpty()) return Pair(null, null)
        val best = nonZero.minByOrNull { it.second }
        val worst = nonZero.maxByOrNull { it.second }
        return Pair(best, worst)
    }
    fun getSmartTip(): String {
        val calendar = java.util.Calendar.getInstance()
        val thisMonth = getTransactionsForMonth(0).filter { !it.isIncome }
        val lastMonth = getTransactionsForMonth(1).filter { !it.isIncome }

        val thisTotal = thisMonth.sumOf { it.amount }
        val lastTotal = lastMonth.sumOf { it.amount }

        // Check savings
        val hasSavings = transactions.any { it.category == "Save" && !it.isIncome }
        if (!hasSavings && transactions.isNotEmpty()) {
            return "💡 You haven't saved anything yet this month. Try adding to your Save category! 🏦"
        }

        // Compare this month to last month
        if (lastTotal > 0.0 && thisTotal > 0.0) {
            val percentChange = ((thisTotal - lastTotal) / lastTotal) * 100
            if (percentChange > 20) {
                return "⚠️ You spent ${"%.0f".format(percentChange)}% more this month than last month. Try to cut back!"
            } else if (percentChange < -20) {
                return "🎉 Great job! You spent ${"%.0f".format(Math.abs(percentChange))}% less this month than last month!"
            }
        }

        // Find biggest expense category
        if (thisMonth.isNotEmpty()) {
            val biggestCategory = thisMonth
                .groupBy { it.category }
                .mapValues { entry -> entry.value.sumOf { it.amount } }
                .maxByOrNull { it.value }

            if (biggestCategory != null && thisTotal > 0) {
                val percent = ((biggestCategory.value / thisTotal) * 100).toInt()
                if (percent > 40) {
                    return "💡 ${biggestCategory.key} is your biggest expense at $percent% of spending this month!"
                }
            }
        }

        // Balance looks good
        if (transactions.isNotEmpty()) {
            val totalIncome = transactions.filter { it.isIncome }.sumOf { it.amount }
            val totalExpenses = transactions.filter { !it.isIncome }.sumOf { it.amount }
            if (totalIncome > totalExpenses) {
                return "💪 Your balance is looking healthy! You're spending less than you earn. Keep it up!"
            }
        }

        return "💡 Keep tracking your spending to get personalized tips!"
    }
}